/******************************************************************************
 * Copyright (c) 2012-2017 All Rights Reserved, http://www.evocortex.com      *
 *  Evocortex GmbH                                                            *
 *  Emilienstr. 1                                                             *
 *  90489 Nuremberg                                                            *
 *  Germany                                                                   *
 *                                                                            *
 * Contributors:                                                              *
 *  Initial version for Linux 64-Bit platform supported by Fraunhofer IPA,    *
 *  http://www.ipa.fraunhofer.de                                              *
 *****************************************************************************/

#ifndef IRDEVICEUVC
#define IRDEVICEUVC

#include <string.h>
#include "IRDevice.h"

namespace evo
{

/**
 * @class IRDeviceUVC
 * @brief UVC device interface (Linux platforms)
 * @author Stefan May (Evocortex GmbH), Matthias Wiedemann (Optris GmbH)
 */
class IRDeviceUVC : public IRDevice
{
public:

  /**
   * Static factory method
   * @param[in] v4lPath The user might force a certain path. If NULL is passed, the path is determined automatically.
   * @þaram[in|out] Lookup parameter: If serial=0, the serial number will be determined automatically (first found device).
   *                                  If serial>0, the method searches for the specific device.
   * @param[in] videoFormatIndex PI imagers might have multiple video formats, e.g. PI400: 0==27Hz, 1==80Hz
   * @return Pointer to class instance (might be NULL, if device is not found)
   */
  static IRDeviceUVC* createInstance(char* v4lPath, unsigned long &serial, int videoFormatIndex);

  /**
   * Standard constructor
   * @param[in] devPath System path to device
   */
  IRDeviceUVC(const char* devPath=NULL);

  /**
   * Destructor
   */
  ~IRDeviceUVC();

  /**
   * Find first device with vendor and product identifier of Optris GmbH
   * @return Serial number (if successfully found)
   */
  unsigned long findFirstDevice();

  /**
   * Find device with specific serial number of Optris GmbH
   * @return Serial number (if successfully found)
   */
  unsigned long findDeviceBySerial(unsigned long serial);

  /**
   * Get UVC path
   * @return UVC path
   */
  char* getPath();

  /**
   * Force serial number
   * @param[in] serno serial number
   */
  void setSerial(unsigned long serno);

  /**
   * Open device
   * @param[in] chFormat format channel
   * @return success
   */
  int openDevice(unsigned int chFormat=0);

  /**
   * Check if device was already opened
   * @return state (open / closed)
   */
  bool isOpen();

  /**
   * Set framerate of device (numerator / denominator)
   * @param[in] numerator numerator of framerate term
   * @param[in] denominator denominator of framerate term
   */
  int setFramerate(unsigned int numerator, unsigned int denominator);

  /**
   * Start video grabbing
   */
  int startStreaming();

  /**
   * Stop video grabbing
   */
  int stopStreaming();

  /**
   * Close device
   * @return success
   */
  int closeDevice();

  /**
   * Acquire one frame
   * @param buffer image data
   * @param timestamp point of time at arrival via V4L2
   */
  IRDeviceError getFrame(unsigned char* buffer, double* timestamp=NULL);

  /**
   * Run device, i.e., treat main thread in blocking mode. The data is polled within this loop for Linux users.
   * It is implemented for the user's convenience, if the main thread is desired to be occupied.
   * User do not need to call this method, if they want to use their own grabbing loop.
   */
  virtual void run();

  /**
   * Exit blocking run method, if previously called.
   */
  virtual void exit();

protected:

  char* _path;

private:

  /**
   * Release frame binding
   */
  int releaseFrame();

  int initMmap();

  int xioctl(int request, void *arg);

  /**
   * Generic find method
   * @param[in] serial Serial number to be found, if serial==0, then first device is returned
   * @return Serial number (if successfully found)
   */
  unsigned long findDevice(unsigned long serial);

  int _fd;

  struct buffer
  {
    void * start;
    size_t length;
  };

  buffer* _buffers;

  unsigned int _cntBuffers;

  int _index;

  size_t _len;

  bool _isStreaming;

  bool _run;
};

} //namespace

#endif // IRDEVICEUVC
