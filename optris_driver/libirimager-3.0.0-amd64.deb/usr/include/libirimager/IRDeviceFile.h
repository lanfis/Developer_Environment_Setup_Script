/******************************************************************************
 * Copyright (c) 2012-2017 All Rights Reserved, http://www.evocortex.com      *
 *  Evocortex GmbH                                                            *
 *  Emilienstr. 1                                                             *
 *  90489 Nuremberg                                                            *
 *  Germany                                                                   *
 *                                                                            *
 * Contributors:                                                              *
 *  Initial version for Linux 64-Bit platform supported by Fraunhofer IPA,    *
 *  http://www.ipa.fraunhofer.de                                              *
 *****************************************************************************/

#ifndef IRDEVICEFILE
#define IRDEVICEFILE

#include <string.h>


//#include <fstream>
#include <stdint.h>
//#include <time.h>

#include "IRDevice.h"

namespace evo
{

#define GPSBUFFERSIZE 80
#define HEADERVERSION 1001

/**
 * @class IRDeviceFile
 * @brief File device interface
 * @author Stefan May (Evocortex GmbH)
 */
class IRDeviceFile : public IRDevice
{
public:

  /**
   * Constructor
   * @param[in] fileBase base name of chunk files
   * @param[in] params camera parameter set
   */
  IRDeviceFile(std::string fileBase, IRDeviceParams &params);

  /**
   * Destructor
   */
  ~IRDeviceFile();

  /**
   * Get hardware revision
   * @return firmware revision
   */
  unsigned short getHwRev(void);

  /**
   * Get firmware revision
   * @return firmware revision
   */
  unsigned short getFwRev(void);

  /**
   * Flag indicating an open file
   * @return true==file is open
   */
  bool                   isOpen();

  /**
   * Acquire one frame
   * @param buffer image data
   * @param timestamp point of time at arrival
   */
  IRDeviceError getFrame(unsigned char* buffer, double* timestamp=NULL);

  /**
   * Start camera stream
   * @return success==true
   */
  virtual int            startStreaming();

  /**
   * Stop camera stream
   * @return success==true
   */
  virtual int            stopStreaming();

  /**
   * Run device, i.e., treat main thread in blocking mode. See documentation of implemented methods for more information.
   */
  virtual void           run();

  /**
   * Exit blocking run method, if previously called.
   */
  virtual void           exit();

  void reset();

protected:


private:

  /**
   * File read access
   * @param[out] rawBuffer data buffer
   * @param[out] nmea GPS data
   */
  bool read(unsigned char* rawBuffer, char nmea[GPSBUFFERSIZE]);

  bool _isReady;

  bool _run;

  std::ifstream* _f;

  std::string* _filename;

  uint32_t _chunk;

  uint32_t _rawBufferSize;

  unsigned char* _rawBuffer;

  char _nmea[GPSBUFFERSIZE];

};

} //namespace

#endif // IRDEVICEFILE
